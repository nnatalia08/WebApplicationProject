package com.easysta.model.enums;

public enum PromotionStatus {
    ACTIVE,
    INACTIVE,
    EXPIRED,
    CANCELLED
}
