package com.easysta.model;

import jakarta.persistence.*;

import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "clients")
public class Client extends User {

    @Column
    private String phoneNumber;

    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL)
    private List<Reservation> reservations;

    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL)
    private List<Rating> ratings;

    @Column
    private String address;

    @Column
    private String preferences;


    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPhone(String phone) {
        this.setPhoneNumber(phone);
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(List<Reservation> reservations) {
        this.reservations = reservations;
    }

    public List<Rating> getRatings() {
        return ratings;
    }

    public void setRatings(List<Rating> ratings) {
        this.ratings = ratings;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPreferences() {
        return preferences;
    }

    public void setPreferences(String preferences) {
        this.preferences = preferences;
    }

    public void setName(String fullName) {
        if (fullName != null && !fullName.trim().isEmpty()) {
            String[] parts = fullName.trim().split(" ", 2);
            this.setFirstName(parts[0]);
            if (parts.length > 1) {
                this.setLastName(parts[1]);
            }
        }
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Client)) return false;
        if (!super.equals(o)) return false;
        Client client = (Client) o;
        return Objects.equals(phoneNumber, client.phoneNumber) &&
                Objects.equals(reservations, client.reservations) &&
                Objects.equals(ratings, client.ratings) &&
                Objects.equals(address, client.address) &&
                Objects.equals(preferences, client.preferences);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), phoneNumber, reservations, ratings, address, preferences);
    }

    @Override
    public String toString() {
        return "Client{" +
                "phoneNumber='" + phoneNumber + '\'' +
                ", reservations=" + reservations +
                ", ratings=" + ratings +
                ", address='" + address + '\'' +
                ", preferences='" + preferences + '\'' +
                "} " + super.toString();
    }
}
