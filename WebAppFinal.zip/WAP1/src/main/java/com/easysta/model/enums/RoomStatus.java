package com.easysta.model.enums;

public enum RoomStatus {
    AVAILABLE,
    OCCUPIED,
    RESERVED,
    UNDER_MAINTENANCE,
    OUT_OF_SERVICE
}
