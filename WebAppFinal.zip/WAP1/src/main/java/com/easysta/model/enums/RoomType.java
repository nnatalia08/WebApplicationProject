package com.easysta.model.enums;

public enum RoomType {
    SINGLE,
    DOUBLE,
    SUITE,
    DELUXE,
    FAMILY,
    PRESIDENTIAL
}
