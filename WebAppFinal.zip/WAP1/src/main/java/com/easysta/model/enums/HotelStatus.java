package com.easysta.model.enums;

public enum HotelStatus {
    ACTIVE,
    INACTIVE,
    UNDER_MAINTENANCE,
    TEMPORARILY_CLOSED
}
