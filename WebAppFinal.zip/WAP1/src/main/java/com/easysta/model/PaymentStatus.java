package com.easysta.model;

public enum PaymentStatus {
    PENDING,
    PAID,
    REFUNDED,
    FAILED
} 