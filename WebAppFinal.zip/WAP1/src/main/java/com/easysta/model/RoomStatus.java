package com.easysta.model;

public enum RoomStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE,
    RESERVED
} 