package com.easysta.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "system_admins")
public class SystemAdmin extends User {
    @Column
    private String department;

    @Column
    private String position;

    @Column
    private boolean isSuperAdmin = false;
}
