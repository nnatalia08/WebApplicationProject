package com.easysta.model;

public enum HotelStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
} 