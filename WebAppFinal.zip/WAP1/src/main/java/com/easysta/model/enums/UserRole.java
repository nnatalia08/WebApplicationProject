package com.easysta.model.enums;

public enum UserRole {
    CLIENT,
    HOTEL_OWNER,
    SYSTEM_ADMIN
}
