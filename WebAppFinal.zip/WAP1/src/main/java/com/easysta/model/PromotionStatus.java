package com.easysta.model;

public enum PromotionStatus {
    ACTIVE,
    EXPIRED,
    CANCELLED
} 