package com.easysta.model.enums;

public enum PaymentStatus {
    PENDING,
    PAID,
    REFUNDED,
    FAILED,
    PARTIALLY_PAID
}
