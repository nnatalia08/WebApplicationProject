package com.easysta.service;

import com.easysta.model.Room;
import com.easysta.repository.RoomRepository;
import com.easysta.dto.request.RoomDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    public void addRoom(RoomDTO roomDTO) {
        Room room = new Room();
        room.setRoomNumber(roomDTO.getRoomNumber());
        room.setType(roomDTO.getType());
        room.setPrice(roomDTO.getPrice());
        roomRepository.save(room);
    }

    public Iterable<Room> getAllRooms() {
        return roomRepository.findAll();
    }
}
