package com.easysta.service;

import com.easysta.model.Reservation;
import com.easysta.repository.ReservationRepository;
import com.easysta.dto.request.ReservationDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    public void addReservation(ReservationDTO reservationDTO) {
        Reservation reservation = new Reservation();
        reservation.setCheckInDate(reservationDTO.getCheckIn());
        reservation.setCheckOutDate(reservationDTO.getCheckOut());
        reservation.setStatus(reservationDTO.getStatus());
        reservationRepository.save(reservation);
    }

    public Iterable<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }
}
