package com.easysta.service;

import com.easysta.model.HotelOwner;
import com.easysta.repository.HotelOwnerRepository;
import com.easysta.dto.request.HotelOwnerDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HotelOwnerService {

    @Autowired
    private HotelOwnerRepository hotelOwnerRepository;

    public void addHotelOwner(HotelOwnerDTO hotelOwnerDTO) {
        HotelOwner hotelOwner = new HotelOwner();
        hotelOwner.setName(hotelOwnerDTO.getName());
        hotelOwner.setEmail(hotelOwnerDTO.getEmail());
        hotelOwnerRepository.save(hotelOwner);
    }

    public Iterable<HotelOwner> getAllHotelOwners() {
        return hotelOwnerRepository.findAll();
    }
}
