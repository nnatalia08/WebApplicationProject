package com.easysta.service;

import com.easysta.model.Rating;
import com.easysta.repository.RatingRepository;
import com.easysta.dto.request.RatingDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RatingService {

    @Autowired
    private RatingRepository ratingRepository;

    public void addRating(RatingDTO ratingDTO) {
        Rating rating = new Rating();
        rating.setScore(ratingDTO.getScore());
        rating.setComment(ratingDTO.getComment());
        ratingRepository.save(rating);
    }

    public Iterable<Rating> getAllRatings() {
        return ratingRepository.findAll();
    }
}
