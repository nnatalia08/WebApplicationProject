package com.easysta.service;

import com.easysta.model.SystemAdmin;
import com.easysta.repository.SystemAdminRepository;
import com.easysta.dto.request.AdminDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SystemAdminService {

    @Autowired
    private SystemAdminRepository systemAdminRepository;

    public void addAdmin(AdminDTO adminDTO) {
        SystemAdmin admin = new SystemAdmin();
        admin.setUsername(adminDTO.getUsername());
        admin.setEmail(adminDTO.getEmail());
        systemAdminRepository.save(admin);
    }

    public Iterable<SystemAdmin> getAllAdmins() {
        return systemAdminRepository.findAll();
    }
}
