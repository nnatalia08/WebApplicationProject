package com.easysta.service;

import com.easysta.dto.request.LoginDTO;
import com.easysta.dto.request.RegisterDTO;
import com.easysta.dto.response.JwtResponseDTO;
import com.easysta.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public JwtResponseDTO login(LoginDTO loginDTO) {
        return new JwtResponseDTO("token");
    }

    public void register(RegisterDTO registerDTO) {
    }
}