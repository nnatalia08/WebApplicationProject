package com.easysta.service;

import com.easysta.model.Hotel;
import com.easysta.repository.HotelRepository;
import com.easysta.dto.request.HotelDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    public void addHotel(HotelDTO hotelDTO) {
        Hotel hotel = new Hotel();
        hotel.setName(hotelDTO.getName());
        hotel.setAddress(hotelDTO.getAddress());
        hotel.setRating(hotelDTO.getRating());
        hotelRepository.save(hotel);
    }

    public Iterable<Hotel> getAllHotels() {
        return hotelRepository.findAll();
    }
}
