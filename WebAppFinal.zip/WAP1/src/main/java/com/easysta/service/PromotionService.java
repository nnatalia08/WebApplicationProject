package com.easysta.service;

import com.easysta.model.Promotion;
import com.easysta.repository.PromotionRepository;
import com.easysta.dto.request.PromotionDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PromotionService {

    @Autowired
    private PromotionRepository promotionRepository;

    public void addPromotion(PromotionDTO promotionDTO) {
        Promotion promotion = new Promotion();
        promotion.setCode(promotionDTO.getCode());
        promotion.setDiscount(promotionDTO.getDiscountPercentage());
        promotion.setValidUntil(promotionDTO.getValidUntil());
        promotionRepository.save(promotion);
    }

    public Iterable<Promotion> getAllPromotions() {
        return promotionRepository.findAll();
    }
}
