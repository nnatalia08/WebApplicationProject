package com.easysta.controller;

import com.easysta.dto.request.PromotionDTO;
import com.easysta.model.Promotion;
import com.easysta.service.PromotionService;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping(path = "/api/promotions")
public class PromotionController {
    private final PromotionService promotionService;

    public PromotionController(PromotionService promotionService) {
        this.promotionService = promotionService;
    }

    @GetMapping
    public Iterable<Promotion> getAllPromotions() {
        return promotionService.getAllPromotions();
    }

    @PostMapping
    public String addPromotion(@RequestBody PromotionDTO promotionDTO) {
        promotionService.addPromotion(promotionDTO);
        return "Promotion added successfully!";
    }
}