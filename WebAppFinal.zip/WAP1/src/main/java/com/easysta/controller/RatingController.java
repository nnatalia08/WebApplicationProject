package com.easysta.controller;

import com.easysta.dto.request.RatingDTO;
import com.easysta.model.Rating;
import com.easysta.service.RatingService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/ratings")
public class RatingController {
    private final RatingService ratingService;

    public RatingController(RatingService ratingService) {
        this.ratingService = ratingService;
    }

    @GetMapping
    public Iterable<Rating> getAllRatings() {
        return ratingService.getAllRatings();
    }

    @PostMapping
    public String addRating(@RequestBody RatingDTO ratingDTO) {
        ratingService.addRating(ratingDTO);
        return "Rating added successfully!";
    }
}
