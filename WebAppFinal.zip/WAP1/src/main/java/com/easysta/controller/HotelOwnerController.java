package com.easysta.controller;

import com.easysta.dto.request.HotelOwnerDTO; //pomyslalam ze to tez niby mozna dodac i skopiować wg wzorów
import com.easysta.model.HotelOwner;
import com.easysta.service.HotelOwnerService;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping(path = "/api/hotel-owners")
public class HotelOwnerController {
    private final HotelOwnerService hotelOwnerService;

    public HotelOwnerController(HotelOwnerService hotelOwnerService) {
        this.hotelOwnerService = hotelOwnerService;
    }

    @GetMapping
    public Iterable<HotelOwner> getAllHotelOwners() {
        return hotelOwnerService.getAllHotelOwners();
    }

    @PostMapping
    public String addHotelOwner(@RequestBody HotelOwnerDTO hotelOwnerDTO) {
        hotelOwnerService.addHotelOwner(hotelOwnerDTO);
        return "Hotel owner added successfully!";
    }
}