package com.easysta.controller;

import com.easysta.dto.request.RoomDTO;
import com.easysta.model.Room;
import com.easysta.service.RoomService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/rooms")
public class RoomController {
    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping
    public Iterable<Room> getAllRooms() {
        return roomService.getAllRooms();
    }

    @PostMapping
    public String addRoom(@RequestBody RoomDTO roomDTO) {
        roomService.addRoom(roomDTO);
        return "Room added successfully!";
    }
}