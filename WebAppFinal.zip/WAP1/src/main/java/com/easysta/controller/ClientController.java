package com.easysta.controller;

import com.easysta.dto.request.ClientDTO;
import com.easysta.model.Client;
import com.easysta.service.ClientService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/clients")
public class ClientController {
    private final ClientService clientService;

    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    @GetMapping
    public Iterable<Client> getAllClients() {
        return clientService.getAllClients();
    }

    @PostMapping
    public String addClient(@RequestBody ClientDTO clientDTO) {
        clientService.addClient(clientDTO);
        return "Client added successfully!";
    }
}