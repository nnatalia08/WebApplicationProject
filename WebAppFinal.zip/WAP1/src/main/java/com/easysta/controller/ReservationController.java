package com.easysta.controller;

import com.easysta.dto.request.ReservationDTO;
import com.easysta.model.Reservation;
import com.easysta.service.ReservationService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/reservations")
public class ReservationController {
    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @GetMapping
    public Iterable<Reservation> getAllReservations() {
        return reservationService.getAllReservations();
    }

    @PostMapping
    public String addReservation(@RequestBody ReservationDTO reservationDTO) {
        reservationService.addReservation(reservationDTO);
        return "Reservation added successfully!";
    }
}
