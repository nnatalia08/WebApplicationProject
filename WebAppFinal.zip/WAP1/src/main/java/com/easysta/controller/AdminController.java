package com.easysta.controller;

import com.easysta.dto.request.AdminDTO;
import com.easysta.model.SystemAdmin;
import com.easysta.service.SystemAdminService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/admin")
public class AdminController {
    private final SystemAdminService adminService;

    public AdminController(SystemAdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping
    public Iterable<SystemAdmin> getAllAdmins() {
        return adminService.getAllAdmins();
    }

    @PostMapping
    public String addAdmin(@RequestBody AdminDTO adminDTO) {
        adminService.addAdmin(adminDTO);
        return "Admin added successfully!";
    }
}