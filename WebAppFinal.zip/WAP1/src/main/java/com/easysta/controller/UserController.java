package com.easysta.controller;

import org.springframework.web.bind.annotation.*;
import com.easysta.service.UserService;
import com.easysta.model.User;
import com.easysta.dto.request.UserDTO;


@RestController
@RequestMapping(path = "/api/users")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public Iterable<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @PostMapping
    public String addUser(@RequestBody UserDTO userDTO) {
        userService.addUser(userDTO);
        return "User added successfully!";
    }
}