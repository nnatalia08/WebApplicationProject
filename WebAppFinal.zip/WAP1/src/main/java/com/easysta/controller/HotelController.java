package com.easysta.controller;

import com.easysta.dto.request.HotelDTO;
import com.easysta.model.Hotel;
import com.easysta.service.HotelService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/hotels")
public class HotelController {
    private final HotelService hotelService;

    public HotelController(HotelService hotelService) {
        this.hotelService = hotelService;
    }

    @GetMapping
    public Iterable<Hotel> getAllHotels() {
        return hotelService.getAllHotels();
    }

    @PostMapping
    public String addHotel(@RequestBody HotelDTO hotelDTO) {
        hotelService.addHotel(hotelDTO);
        return "Hotel added successfully!";
    }
}