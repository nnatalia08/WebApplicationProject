package com.easysta.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class PriceCalculator {

    public static BigDecimal calculateTotalPrice(BigDecimal basePrice, int numberOfDays) {
        return basePrice.multiply(BigDecimal.valueOf(numberOfDays));
    }

    public static BigDecimal applyDiscount(BigDecimal price, int discountPercentage) {
        if (discountPercentage < 0 || discountPercentage > 100) {
            return price;
        }

        BigDecimal discount = price.multiply(BigDecimal.valueOf(discountPercentage))
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        return price.subtract(discount);
    }

    public static BigDecimal calculateTax(BigDecimal price, int taxPercentage) {
        BigDecimal tax = price.multiply(BigDecimal.valueOf(taxPercentage))
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        return price.add(tax);
    }
}
