package com.easysta.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtils {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static String getCurrentDate() {
        return LocalDate.now().format(DATE_FORMATTER);
    }

    public static boolean isDateValid(String date) {
        try {
            LocalDate.parse(date, DATE_FORMATTER);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isDateInFuture(String date) {
        try {
            LocalDate inputDate = LocalDate.parse(date, DATE_FORMATTER);
            return inputDate.isAfter(LocalDate.now());
        } catch (Exception e) {
            return false;
        }
    }
}
