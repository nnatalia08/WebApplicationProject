package com.easysta.util;

import org.springframework.stereotype.Component;

@Component
public class ValidationUtils {

    public boolean isValidEmail(String email) {
        if (email == null) return false;
        return email.contains("@") && email.contains(".");
    }

    public boolean isValidPassword(String password) {
        if (password == null) return false;
        return password.length() >= 6;
    }

    public boolean isValidPhoneNumber(String phone) {
        if (phone == null) return false;
        return phone.matches("\\d{9,}");  // At least 9 digits
    }
}