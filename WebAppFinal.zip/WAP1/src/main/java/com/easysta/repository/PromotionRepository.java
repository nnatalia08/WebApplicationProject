package com.easysta.repository;

import com.easysta.model.Promotion;
import org.springframework.data.repository.CrudRepository;

public interface PromotionRepository extends CrudRepository<Promotion, Long> {

}

