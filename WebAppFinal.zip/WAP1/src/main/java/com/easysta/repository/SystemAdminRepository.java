package com.easysta.repository;

import com.easysta.model.SystemAdmin;
import org.springframework.data.repository.CrudRepository;

public interface SystemAdminRepository extends CrudRepository<SystemAdmin, Long> {
}