package com.easysta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class EasyStayApplication {

    public static void main(String[] args) {
        SpringApplication.run(EasyStayApplication.class, args);
    }
}

